"""
URL configuration for duplio project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from app.views import *
from django.conf import settings
from django.conf.urls.static import static
urlpatterns = [
    path('admin/', admin.site.urls),
    path('',home),
    path('about/',about),
    path('medicine/',medicine),
    path('buy/',buy),
    path('appointment/',appointment),
    path('contact/',contact),
    path('accounts/login/',sign),
    path('accounts/logout/',signout),
     path('orders',orders),
    path('order/<int:id>/',makeorder),
    path('order/payment/success/<str:pay>/<str:id>',paysuccess),
    path('order/payment/failed/<str:pay>/<str:id>',payfailed),
    #admin
    path('a',dashboard),
    path('a/contacts/',contacts),
    #category
    
    path('a/categories',categories),
    path('a/categories/edit/<int:id>',editcategory),
    path('a/categories/delete/<int:id>',delcategory),
    
    #products
    path('a/addproduct',addproduct),
 
    path('a/editproduct/<int:id>',editproduct),
    path('a/deleteproduct/<int:id>',deleteproduct),
    path('a/viewproducts',viewproducts),
    #orders
    path('a/orders',aorders),
    path('a/order/update/<int:id>',updateorder),
    
]+ static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
