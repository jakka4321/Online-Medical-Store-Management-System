from django.shortcuts import render,redirect
from django.contrib import messages
from django.contrib.auth import login,logout,authenticate
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required,user_passes_test
from datetime import datetime,timedelta
from .forms import *
import razorpay
# Create your views here.
def home(r):
    return render(r,'index.html')
def about(r):
    return render(r,'about.html')
def contact(r):
    form=ContactForm(initial={'name':r.user,'email':r.user.email})
    if r.method=="POST":
        form=ContactForm(r.POST)
        form.instance.user=r.user
        form.instance.date=datetime.today()
        if form.is_valid():
            form.save()
            return redirect('/')
    return render(r,'contact.html',{"form":form})

def medicine(r):
    cat=Category.objects.all()
    # print(product)
    product={}
    for i in cat:
        l=[]
        p=Product.objects.filter(category_id=i.id)
        if len(p)>0:
            l+=p
        if len(l)>0:
            random.shuffle(l)
            product[i]=l
    return render(r,'medicine.html',{"products":product})
import random
def buy(r):
    cat=Category.objects.all()
    # print(product)
    product={}
    for i in cat:
        l=[]
        p=Product.objects.filter(category_id=i.id)
        if len(p)>0:
            l+=p
        if len(l)>0:
            random.shuffle(l)
            product[i]=l
    print(product)
    return render(r,'buy.html',{"products":product})
def appointment(r):
    return render(r,'appointment.html')
def sign(r):
    if r.method=="POST":
        if "login" in r.POST:
            username=r.POST['username']
            password=r.POST['password']
            user=authenticate(username=username.title(),password=password)
            if user is not None:
                login(r,user)
                if user.is_superuser:
                    return redirect('/a')
                else:
                    return redirect('/')
            else:
                messages.error(r,"Invalid login credentials")
        if "signup" in r.POST:
            username=r.POST['username1']
            email=r.POST['email']
            password=r.POST['password2']
            password1=r.POST['password1']
            if password!=password1 :
                messages.error(r,"Passwords not matches")
            elif User.objects.filter(username=username.title()):
                messages.error(r,"Username already exists...!")
            elif User.objects.filter(email=email):
                messages.error(r,"Email already taken...!")
            elif len(password)<8:
                messages.error(r,"Password must be eight characters")
            else:
                User.objects.create_user(username=username.title(),email=email,password=password)
                user=authenticate(username=username.title(),password=password)
                if user is not None:
                    login(r,user)
                    return redirect('/')
    return render(r,'Login.html')

def signout(r):
    logout(r)
    return redirect('/')



#admin
@user_passes_test(lambda u:u.is_superuser)
def dashboard(r):
    return render(r,'admin/home.html')
@user_passes_test(lambda u:u.is_superuser)
def contacts(r):
    c=Contact.objects.all()
    return render(r,'admin/contacts.html',{"contacts":c})
#categories
@user_passes_test(lambda u:u.is_superuser)
def categories(r):
    category=Category.objects.all()
    form=CategoryForm()
    if r.method=="POST":
        form=CategoryForm(data=r.POST)
        if form.is_valid():
            form.save()
            return redirect("/a/categories")
    return render(r,'admin/categories.html',{"category":category,"form":form})


@user_passes_test(lambda u:u.is_superuser)
def editcategory(r,id):
    category=Category.objects.all()
    c=Category.objects.get(id=id)
    form=CategoryForm(instance=c)
    if r.method=="POST":
        form=CategoryForm(data=r.POST,instance=c)
        if form.is_valid():
            form.save()
            return redirect("/a/categories")
    return render(r,'admin/categories.html',{"category":category,"form":form})
def delcategory(r,id):
    Category.objects.get(id=id).delete()
    return redirect("/a/categories")

    

#products

@user_passes_test(lambda u:u.is_superuser)
def addproduct(request):
    product_form = ProductForm()
    if request.method == 'POST':
        product_form=ProductForm(request.POST,request.FILES)
        if product_form.is_valid():
            product_form.save()
            return redirect(f'/a/viewproducts')
    return render(request, 'admin/addproduct.html', {'product_form': product_form,})
@user_passes_test(lambda u:u.is_superuser)
def editproduct(request, id):
    p=Product.objects.get(id=id)
    product_form = ProductForm(instance=p)   
    if request.method == 'POST':    
        product_form=ProductForm(request.POST,request.FILES,instance=p)
        if product_form.is_valid():
            product_form.save()
            return redirect(f'/a/viewproducts')
    return render(request, 'admin/addproduct.html', {'product_form': product_form,})

@user_passes_test(lambda u:u.is_superuser)
def viewproducts(r):
    product=Product.objects.all()
    return render(r,"admin/viewproducts.html",{"product":product})
@user_passes_test(lambda u:u.is_superuser)
def deleteproduct(r,id):
    product=Product.objects.get(id=id)
    product.delete()
    return redirect("/a/viewproducts")

@user_passes_test(lambda u:u.is_superuser)
def aorders(r):
    order=Order.objects.filter(order_status=True)
    return render(r,'admin/orders.html',{"orders":order})
@user_passes_test(lambda u:u.is_superuser)
def updateorder(r,id):
    order=Order.objects.get(id=id)
    form=OrderForm(instance=order)
    if r.method=="POST":
        form=OrderForm(r.POST,instance=order)
        if form.is_valid():
            form.save()
            return redirect(f'/a/orders')

    return render(r,'admin/updateorder.html',{"form":form})
@login_required
def makeorder(r,id):
    product=Product.objects.get(id=id)
    form=AddressForm()
    exists=0
    if Address.objects.filter(user=r.user):
        exists=1
        form=AddressForm(instance=Address.objects.get(user=r.user))
    client=razorpay.Client(auth=("rzp_test_euB1g3Ioe7wejB","k0phaX9LIQtibmploFiUPjs0"))
    payment=client.order.create({"amount":float(product.price*100),'currency':'INR','payment_capture':1})
    # print(payment)
    if r.method=="POST":
        if exists:
            form=AddressForm(r.POST,instance=Address.objects.get(user=r.user))
        else:
            form=AddressForm(r.POST)
            form.instance.user=r.user
        if form.is_valid():
            form.save()
            exists=1
    if exists:
        address=Address.objects.get(user=r.user)
        Order(order_id=payment['id'],delivery_status="Pending",user=r.user,product=product,address=address.address,full_name=address.full_name,mobile_no=address.mobile_no,alternate_no=address.alternate_no,pin_code=address.pin_code,order_date=datetime.today()).save()
    return render(r,'address.html',{"form":form,"exists":exists,"payment":payment})

@login_required
def paysuccess(r,pay,id):
    update_order(id,pay,True)
    return redirect('/orders')
@login_required
def payfailed(r,pay,id):
    update_order(id,pay,False)
    return redirect('/orders')
def update_order(id,pay,status):
    ob=Order.objects.get(order_id=id)
    ob.payment_id=pay
    ob.order_status=True 
    ob.payment_status=status    
    ob.save()
@login_required
def orders(r):
    ord=Order.objects.filter(user=r.user).filter(order_status=True)
    return render(r,'orders.html',{"orders":ord})