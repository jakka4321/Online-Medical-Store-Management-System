from django.db import models
from django.contrib.auth.models import User
# Create your models here.

# Create your models here.

class Category(models.Model):
    category=models.CharField(max_length=30)
    def __str__(s):
        return s.category

stars=(("1","1"),("12","2"),("123","3"),("1234","4"),("12345","5"))

class Product(models.Model):
    name=models.CharField(max_length=40)
    price=models.DecimalField(max_digits=10,decimal_places=2)
    image=models.ImageField(upload_to="product")
    description=models.TextField()
    ratings=models.CharField(choices=stars,max_length=5)
    category=models.ForeignKey(Category,on_delete=models.CASCADE)
    def __str__(s):
        return s.name

class Address(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    full_name=models.CharField(max_length=20)
    mobile_no=models.CharField(max_length=10)
    alternate_no=models.CharField(max_length=10)
    address=models.TextField()
    pin_code=models.CharField(max_length=6)


class Contact(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    name=models.CharField(max_length=20)
    mobile_no=models.CharField(max_length=10)
    email=models.EmailField()
    message=models.TextField()
    date=models.DateField()

class Order(models.Model):
    payment_id=models.CharField(max_length=100,blank=True)
    order_id=models.CharField(max_length=100)
    payment_status=models.BooleanField(default=False)
    delivery_status=models.CharField(max_length=20,choices=(("Confirmed","Confirmed"),("Cancelled","Cancelled"),("Shipping","Shipping"),("Shipped","Shipped"),("Out for Delivery","Out for Delivery"),("Delivered","Delivered"),("Returned","Returned")))
    order_status=models.BooleanField(blank=True,default=False)
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    product=models.ForeignKey(Product,on_delete=models.CASCADE)
    full_name=models.CharField(max_length=20)
    mobile_no=models.CharField(max_length=10)
    alternate_no=models.CharField(max_length=10)
    address=models.TextField()
    pin_code=models.CharField(max_length=6)
    order_date=models.DateField(null=True,blank=True)

    
   

