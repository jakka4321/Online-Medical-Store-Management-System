from .models import *
from django import forms

class CategoryForm(forms.ModelForm):
    class Meta:
        model=Category
        fields='__all__'
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.widget.attrs.update({'class': 'form-control'})
    
    def clean_category(self):
        sub=self.cleaned_data.get('category')
        return sub.title()
    
       
class ContactForm(forms.ModelForm):
    class Meta:
        model=Contact
        fields=['name','mobile_no','email','message']
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.widget.attrs.update({'class': 'form-control'})
    def clean_mobile_no(self):
        m=self.cleaned_data.get('mobile_no')
        if re.match(r'^\d{10}$',m):
            return m
        else:
            raise forms.ValidationError("Enter valid number")
   
    
       


class ProductForm(forms.ModelForm):
    class Meta:
        model=Product
        fields='__all__'
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.widget.attrs.update({'class': 'form-control'})
    def clean_halfstars(self):
        n=self.cleaned_data.get('halfstars')
        r=self.cleaned_data.get('ratings')
        
        if r=="12345":
            n=0
        return n


import re
class AddressForm(forms.ModelForm):
    class Meta:
        model=Address
        fields=['full_name','mobile_no','alternate_no','address','pin_code']
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.widget.attrs.update({'class': 'form-control'})
    def clean_mobile_no(self):
        m=self.cleaned_data.get('mobile_no')
        if re.match(r'^\d{10}$',m):
            return m
        else:
            raise forms.ValidationError("Enter valid number")
    def clean_pin_code(self):
        m=self.cleaned_data.get('pin_code')
        if re.match(r'^\d{6}$',m):
            return m
        else:
            raise forms.ValidationError("Enter valid pin code")
    def clean_alternate_no(self):
        m=self.cleaned_data.get('alternate_no')
        if re.match(r'^\d{10}$',m):
            return m
        else:
            raise forms.ValidationError("Enter valid number")
class OrderForm(forms.ModelForm):
    class Meta:
        model=Order
        fields=['delivery_status']
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.widget.attrs.update({'class': 'form-control'})